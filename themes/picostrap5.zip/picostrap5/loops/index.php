<?php 
/*
Enjoy the silence
*/ 