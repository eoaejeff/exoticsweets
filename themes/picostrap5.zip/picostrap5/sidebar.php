<?php if (is_active_sidebar( 'main-sidebar' )): ?>

    <div class="wrapper bg-light p-3" id="wrapper-main-sidebar">
    
        <?php dynamic_sidebar( 'main-sidebar' ); ?>
    
    </div>

<?php endif ?>
		